import logging
import optparse
import os

import gettext
from gettext import gettext as _
gettext.textdomain('my-fs-cli')

from subprocess import *
from xml.dom.minidom import parse, parseString
from my_fs_cli import my_fs_cliconfig

LEVELS = (  logging.ERROR,
            logging.WARNING,
            logging.INFO,
            logging.DEBUG,
            )
## Require Data ##
# XML String Data for .fonts.conf #
xml_data = """<?xml version="1.0" encoding="utf-8"?><!DOCTYPE fontconfig  SYSTEM 'fonts.dtd'><fontconfig>
<!--- Myanmar Font Switcher configuration. -->
	<match targe="pattern">
		<test compare="eq" name="lang" qual="any"><string>my</string></test>
		<edit mode="assign" name="family">
			<string>zawgyi-one</string>
		</edit>
	</match>
<!--- Please do not modify the above lines. You can add additional configuration below. -->
</fontconfig>"""

# .fonts.conf File Path #
conf_file = os.getenv("HOME") + "/.fonts.conf"

# Pre-defined Myanmar Unicode Font #
# You can also change to "padauk", "myanmar3", etc.#
uni = "TharLon"

####

# Get Keyboard Layout
def get_layout():
    out_file = Popen("gconftool-2 --get '/desktop/gnome/peripherals/keyboard/kbd/layouts'", shell=True, stdout=PIPE).stdout
    out = out_file.read().strip()
    out_file.close()
    return out

# Set fallback font
def set_fallback(fontname):
    doc = parse(conf_file)
    doc.getElementsByTagName('string')[1].firstChild.nodeValue = fontname
    font_conf = open(conf_file, "w")
    doc.writexml(font_conf, encoding="utf-8")
    font_conf.close()

def main():
    version = my_fs_cliconfig.__version__
    # Support for command line options.
    usage = _("my-fs-cli [options]")
    parser = optparse.OptionParser(version="%%prog %s" % version, usage=usage)
    parser.add_option('-d', '--debug', dest='debug_mode', action='store_true',
        help=_('Print the maximum debugging info (implies -vv)'))
    parser.add_option('-v', '--verbose', dest='logging_level', action='count',
        help=_('set error_level output to warning, info, and then debug'))
    # Custom font Assignment.
    parser.add_option("-f", "--font", type="string", dest="fontname", default=uni, help=_("Custom Font Assignment"))
    parser.set_defaults(logging_level=0, foo=None)
    (options, args) = parser.parse_args()

    # set the verbosity
    if options.debug_mode:
        options.logging_level = 3
    logging.basicConfig(level=LEVELS[options.logging_level], format='%(asctime)s %(levelname)s %(message)s')

    if options.fontname == "":
        print "Font name is not set and used Default"
        options.fontname = "TharLon"
        print options.fontname

	# Check .fonts.conf file and Create
    try:
        with open(conf_file) as f: pass
    except IOError as e:
        with open(conf_file, "w") as c:
            xml_doc = parseString(xml_data)
            c.write( xml_doc.toxml() )
            c.close()
            Popen("gconftool-2 --set --type list --list-type string '/desktop/gnome/peripherals/keyboard/kbd/layouts' '[us,mm\tzawgyi]'", shell=True)

    doc = parse(conf_file)
    currentfont = doc.getElementsByTagName('string')[1].firstChild.nodeValue
    print "Current Font : " + currentfont

    # Main component - Toggle Layout and Default Fallback Font
    zgy_layout = "[us,mm\tzawgyi]"
    uni_layout = "[us,mm\tmm3]"
    zgy = "zawgyi-one"
    layout = get_layout()
    if layout == zgy_layout:
        Popen("gconftool-2 --set --type list --list-type string '/desktop/gnome/peripherals/keyboard/kbd/layouts' '[us,mm\tmm3]'", shell=True)
        set_fallback(options.fontname)
        print "Changed Font : " + options.fontname
    else:
        Popen("gconftool-2 --set --type list --list-type string '/desktop/gnome/peripherals/keyboard/kbd/layouts' '[us,mm\tzawgyi]'", shell=True)
        set_fallback(zgy)
        print "Changed Font : " + zgy

    logging.debug(_('end of prog'))


if __name__ == "__main__":
    main()
