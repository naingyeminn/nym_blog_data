put "zawgyi" in /usr/share/X11/xkb/symbols
replace or edit "evdev.xml" in /usr/shre/X11/xkb/rules
