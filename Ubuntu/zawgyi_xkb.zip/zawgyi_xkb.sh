#!/bin/bash
sudo cp zawgyi /usr/share/X11/xkb/symbols/zawgyi
sudo cp evdev.xml /usr/shre/X11/xkb/rules/evdev.xml
echo "Finish and Test Now"
